const config = {
    clientKey: '',
    host: 'https://api.yescaptcha.com',

    autorun: true,
    imageclassification: false, 
    hcaptcha: false,
    imagetotext: false,
    rainbow: true,
    times: 200,
    isTextCaptcha: false,
    endTimes: '20',
    isAutoClickCheckBox: true, 
    checkBoxClickDelayTime: "500",
    isOpenEndTimes: true,
    isOpenCloudflare: false,
    isAutoSubmit: true,
    autoSubmitDelayTime: 100,
    autoSubmitDelayFloatRate: 0.1,
    workStatusFlag: '',
    jsControlObjectName: 'yesCaptcha',
    allowJsInject: true,
    network: {
        hcaptchaVerifyFailDelay: 1000,
        hcaptchaVerifyTry: 3,
        recaptchaVerifyFailDelay: 1000,
        recaptchaVerifyTry: 2,
        funcaptchaVerifyFailDelay: 1000,
        funcaptchaVerifyTry: 3
    },
    hcaptchaConfig: {
        isPassDragChallenge: false,
        isAutoRefresh: false,
        isSwitchToEnglishContent: false,
        isPassMoveCanvasChallenge: false
    },
    funcaptchaConfig: {
        isOpen: true,
        actionAfterRecSuccess: "nothing",
        actionAfterOneRecFail: "nothing",
        actionAfterRecFail: "nothing",
        actionDelay: 3000,
        isAutoClickPrePage: true
    },

    recaptchaConfig: {
        isOpen: false,
        isUseNewScript: false,
        delayFor1X1: 3000,
        isAdaptInvisible: false,
        isOpenProtocol: false,
        V3TaskType: 'RecaptchaV3TaskProxylessM1S7',
        V2TaskType: 'RecaptchaV2TaskProxyless'
    },
    textCaptchaConfig: {
        isTransToUppercase: false
    },
    blackListConfig: {
        isOpen: false,
        urlList: []
    },
    whiteListConfig: {
        isOpen: false,
        urlList: []
    },
    awsCaptchaConfig: {
        isOpen: true
    },
    isHideKey: false
}
chrome.storage.local.get(['config'], function (result) {
    if (result.config) return
    if (chrome.management.getAll) {
        chrome.management.getAll((extensions) => {
            extensions.filter(item =>
                item.type === 'extension'
                && item.name.includes("YesCaptcha")
                && item.enabled === true
            ).length > 1 && (config.isInstallConflict = true)
            chrome.storage.local.set({ config })
        });
    } else {
        chrome.storage.local.set({ config })
    }
})